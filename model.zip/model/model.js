// const mongoose = require('mongoose')
// const Schema = mongoose.Schema;

// const Postscema = new Schema({
//     name:{
//         type:String,
//         require:true
//     },

//     age:{

//         type:Number,
//         require:true

        
//     },
//     category:{
//         type:String,
//         require:true

//     }
// });
// module.exports = mongoose.model('Student',Postscema);
