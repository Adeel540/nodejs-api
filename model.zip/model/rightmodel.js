const mongoose = require('mongoose')

const rightscema = new mongoose.Schema({
    
    staf_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'staff'
    },
    right:{
        type:String
    }
},{
    timestamps:true

  
});
module.exports = mongoose.model('Right',rightscema);
